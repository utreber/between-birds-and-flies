fährt von der Seite ein, erst nur das Handy, dann kommen die Notifications dazu und anschließend die beiden Personen. Wird noch animiert. Reihenfolge ist anhand Step 01-03 gekennzeichnet.
