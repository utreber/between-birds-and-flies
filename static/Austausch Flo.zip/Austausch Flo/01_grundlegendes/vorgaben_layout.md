## **Grundlegendes:**

**Fließtext:** FK Grotesk Medium 30px (1rem), Zeilenabstand 36px 

**Überschriften:** " " mit Unterstreichung

**Zitate: **40px (1.333rem)

**Fakten/Zahlen:** 150px (5rem), Zeilenabstand 180px

**Sprachauswahl:** 18px (0,6rem), ausgewählte Sprache unterstrichen

**Seitenabstand:** 113px von beiden Seiten

**Absatzbreite:** 804px

**Farben für Hintergrund:** 

\#EB88B6 auf 25%

\#FE421D auf 16%

\#007CFA auf 10%

\#FBB030 auf 25%

\#FDA492
