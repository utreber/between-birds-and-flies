* [ ] Wenn Illustration "lädt" sollte der Text stehen bleiben damit man sich auf die Illustration konzentrieren kann
* [ ] Illustrationen die sich nicht füllen fahren von der Seite ein anstatt "zu erscheinen", z.B. die Schildkröte in der Hand
* [ ] Text mit automatischer Silbentrennung, damit nicht so große "Risse" im Fließtext entstehen


